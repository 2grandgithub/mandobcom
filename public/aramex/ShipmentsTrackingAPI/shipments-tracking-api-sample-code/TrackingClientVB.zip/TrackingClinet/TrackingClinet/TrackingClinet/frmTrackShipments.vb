﻿Imports TrackingClinet.TrackingReference
Imports System.Net
Imports System.Text
Imports System.IO

Public Class frmTrackShipments

    Private Sub btnAddWaybill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddWaybill.Click
        AddWaybillToList()
    End Sub

    Private Sub AddWaybillToList()
        If (String.IsNullOrEmpty(txtWaybillNumber.Text.Trim())) Then Return
        lbWaybills.Items.Add(txtWaybillNumber.Text.Trim())
        txtWaybillNumber.Text = String.Empty
        txtWaybillNumber.Focus()
    End Sub

    Private Sub txtWaybillNumber_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtWaybillNumber.KeyDown
        If (e.KeyCode = Keys.Enter) Then AddWaybillToList()
    End Sub

    Private Sub btnSubmitRequest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmitRequest.Click
        Cursor.Current = Cursors.WaitCursor

        Dim _Request As New ShipmentTrackingRequest
        _Request.ClientInfo = New ClientInfo
        _Request.ClientInfo.AccountCountryCode = txtAccountCountryCode.Text.Trim()
        _Request.ClientInfo.AccountEntity = txtAccountEntity.Text.Trim()
        _Request.ClientInfo.AccountNumber = txtAccountNumber.Text.Trim()
        _Request.ClientInfo.AccountPin = txtAccountPin.Text.Trim()
        _Request.ClientInfo.UserName = txtUsername.Text.Trim()
        _Request.ClientInfo.Password = txtPassword.Text.Trim()
        _Request.ClientInfo.Version = txtVersion.Text.Trim()

        _Request.Transaction = New Transaction
        _Request.Transaction.Reference1 = txtReference1.Text.Trim()
        _Request.Transaction.Reference2 = txtReference2.Text.Trim()
        _Request.Transaction.Reference3 = txtReference3.Text.Trim()
        _Request.Transaction.Reference4 = txtReference4.Text.Trim()
        _Request.Transaction.Reference5 = txtReference5.Text.Trim()

        Dim _Shipments As New List(Of String)
        For _Index As Integer = 0 To lbWaybills.Items.Count - 1
            _Shipments.Add(lbWaybills.Items(_Index).ToString())
        Next
        _Request.Shipments = _Shipments.ToArray()

        _Request.GetLastTrackingUpdateOnly = cbGetLastTrackingUpdateOnly.Checked

        Dim _Response As ShipmentTrackingResponse = Nothing
        Dim _Client As New Service_1_0Client

        Try
            _Client.Open()
            _Response = _Client.TrackShipments(_Request)
            _Client.Close()

            Using _frmTrackShipmentsCallResponse As New frmTrackShipmentsCallResponse
                _frmTrackShipmentsCallResponse.Response = _Response
                _frmTrackShipmentsCallResponse.ShowDialog(Me)
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Cursor.Current = Cursors.Default
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        lbWaybills.Items.Clear()

        'Dim request As WebRequest = WebRequest.Create("http://ws.dev.aramex.net/shippingapi/tracking/service_1_0.svc ")
        '' Set the Method property of the request to POST.
        'request.Method = "POST"
        '' Create POST data and convert it to a byte array.
        'Dim postData As String = "This is a test that posts this string to a Web server."
        'Dim byteArray As Byte() = Encoding.UTF8.GetBytes(postData)
        '' Set the ContentType property of the WebRequest.
        'request.ContentType = "text/xml; charset=utf-8"
        '' Set the ContentLength property of the WebRequest.
        'request.ContentLength = byteArray.Length
        '' Get the request stream.
        'Dim dataStream As Stream = request.GetRequestStream()
        '' Write the data to the request stream.
        'dataStream.Write(byteArray, 0, byteArray.Length)
        '' Close the Stream object.
        'dataStream.Close()
        '' Get the response.
        'Dim response As WebResponse = request.GetResponse()
        '' Display the status.
        'Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
        '' Get the stream containing content returned by the server.
        'dataStream = response.GetResponseStream()
        '' Open the stream using a StreamReader for easy access.
        'Dim reader As New StreamReader(dataStream)
        '' Read the content.
        'Dim responseFromServer As String = reader.ReadToEnd()
        '' Display the content.
        'MessageBox.Show(responseFromServer)
        '' Clean up the streams.
        'reader.Close()
        'dataStream.Close()
        'response.Close()

    End Sub
End Class