﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TrackingClientCSharp.TrackingReference;

namespace TrackingClientCSharp
{
    public partial class frmTrackShipments : Form
    {
        public frmTrackShipments()
        {
            InitializeComponent();
        }

        private void btnAddWaybill_Click(object sender, EventArgs e)
        {
            AddWaybillToList();
        }

        private void AddWaybillToList()
        {
            if ((string.IsNullOrEmpty(txtWaybillNumber.Text.Trim())))
                return;
            lbWaybills.Items.Add(txtWaybillNumber.Text.Trim());
            txtWaybillNumber.Text = string.Empty;
            txtWaybillNumber.Focus();
        }

        private void txtWaybillNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter))
                AddWaybillToList();
        }

        private void btnSubmitRequest_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ShipmentTrackingRequest _Request = new ShipmentTrackingRequest();
            _Request.ClientInfo = new ClientInfo();
            _Request.ClientInfo.AccountCountryCode = txtAccountCountryCode.Text.Trim();
            _Request.ClientInfo.AccountEntity = txtAccountEntity.Text.Trim();
            _Request.ClientInfo.AccountNumber = txtAccountNumber.Text.Trim();
            _Request.ClientInfo.AccountPin = txtAccountPin.Text.Trim();
            _Request.ClientInfo.UserName = txtUsername.Text.Trim();
            _Request.ClientInfo.Password = txtPassword.Text.Trim();
            _Request.ClientInfo.Version = txtVersion.Text.Trim();

            _Request.Transaction = new Transaction();
            _Request.Transaction.Reference1 = txtReference1.Text.Trim();
            _Request.Transaction.Reference2 = txtReference2.Text.Trim();
            _Request.Transaction.Reference3 = txtReference3.Text.Trim();
            _Request.Transaction.Reference4 = txtReference4.Text.Trim();
            _Request.Transaction.Reference5 = txtReference5.Text.Trim();

            List<string> _Shipments = new List<string>();
            for (int _Index = 0; _Index <= lbWaybills.Items.Count - 1; _Index++)
            {
                _Shipments.Add(lbWaybills.Items[_Index].ToString());
            }
            _Request.Shipments = _Shipments.ToArray();

            _Request.GetLastTrackingUpdateOnly = cbGetLastTrackingUpdateOnly.Checked;

            ShipmentTrackingResponse _Response = null;
            Service_1_0Client _Client = new Service_1_0Client();

            try
            {
                _Client.Open();
                _Response = _Client.TrackShipments(_Request);
                _Client.Close();

                using (frmTrackShipmentsCallResponse _frmTrackShipmentsCallResponse = new frmTrackShipmentsCallResponse())
                {
                    _frmTrackShipmentsCallResponse.Response = _Response;
                    _frmTrackShipmentsCallResponse.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Cursor.Current = Cursors.Default;

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lbWaybills.Items.Clear();
        }

    }
}
